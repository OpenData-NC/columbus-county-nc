.. currentmodule:: kombu.transport.mongodb

.. automodule:: kombu.transport.mongodb

    .. contents::
        :local:

    Transport
    ---------

    .. autoclass:: Transport
        :members:
        :undoc-members:

    Channel
    -------

    .. autoclass:: Channel
        :members:
        :undoc-members:
