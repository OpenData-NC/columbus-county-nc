from handler import GELFHandler, WAN_CHUNK, LAN_CHUNK
