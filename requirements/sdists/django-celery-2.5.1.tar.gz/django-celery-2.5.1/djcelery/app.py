from __future__ import absolute_import

from celery.app import default_app


#: The Django-Celery app instance.
app = default_app
