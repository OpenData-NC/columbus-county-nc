#[[[section first]]]
print "Hi!"
#[[[endsection]]]

print "More"
