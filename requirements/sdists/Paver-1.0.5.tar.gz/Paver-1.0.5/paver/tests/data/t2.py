#[[[section second]]]
import sys

#[[[section inner]]]
print sys.path
#[[[endsection]]]
#[[[endsection]]]
