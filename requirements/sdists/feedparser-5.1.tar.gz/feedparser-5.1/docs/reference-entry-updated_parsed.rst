.. _reference.entry.updated_parsed:

:py:attr:`entries[i].updated_parsed`
====================================

The date this entry was last updated, as a standard :program:`Python` 9-tuple.


.. rubric:: Comes from

* /atom10:feed/atom10:entry/atom10:updated
* /atom03:feed/atom03:entry/atom03:modified
* /rss/channel/item/pubDate
* /rss/channel/item/dc:date
* /rss/channel/item/dcterms:modified
* /rdf:RDF/rdf:item/dc:date
* /rdf:RDF/rdf:item/dcterms:modified


.. seealso::

    * :ref:`reference.entry.updated`
