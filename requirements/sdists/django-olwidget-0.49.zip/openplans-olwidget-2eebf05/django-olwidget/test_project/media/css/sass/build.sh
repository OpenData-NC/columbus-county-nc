compass -c config.rb
