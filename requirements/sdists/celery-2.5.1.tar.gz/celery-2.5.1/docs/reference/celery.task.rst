=====================================================
 celery.task
=====================================================

.. contents::
    :local:
.. currentmodule:: celery.task

.. automodule:: celery.task

    .. autofunction:: task

    .. autofunction:: periodic_task

    .. autoclass:: Task

        .. seealso::
            :class:`celery.task.base.BaseTask`.
