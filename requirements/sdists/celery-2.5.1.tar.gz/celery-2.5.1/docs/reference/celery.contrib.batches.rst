.. currentmodule:: celery.contrib.batches

.. automodule:: celery.contrib.batches

    **API**

    .. autoclass:: Batches
        :members:
        :undoc-members:
    .. autoclass:: SimpleRequest
        :members:
        :undoc-members:
